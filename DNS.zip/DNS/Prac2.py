
#rail fence
def main():
    layers = int(input("Enter number of layers: "))
    print("Encrypted text:", encrypt(layers, input("Enter plain text: ").upper().replace(" ", "")))

def encrypt(layers, plain_text):
    if layers <= 1:
        return plain_text  # No encryption needed for 1 or fewer layers

    rail = [''] * layers
    row, direction = 0, 1

    for char in plain_text:
        rail[row] += char
        if row == 0:
            direction = 1
        elif row == layers - 1:
            direction = -1
        row += direction

    return ''.join(rail)


if __name__ == "__main__":
    main()


"""
#simple columnar cipher
def main():
    key = input("Enter Key: ")
    userval = input("Enter the value: ")
    col = len(key)
    if len(userval) % col != 0:
        userval += 'x' * (col - (len(userval) % col))
    userval = userval.replace(" ", "")
    o = [i for i in key]
    h = [userval[i::col] for i in range(col)]
    
    dic = dict(zip(o, h))
    
    sorted_keys = sorted(dic.keys())
    cipher_text = "".join(dic[i] for i in sorted_keys)
    
    print("Encrypted text: " + cipher_text)

if __name__ == '__main__':
    main()
"""

