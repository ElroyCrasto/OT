"""
def caesar_cipher(encrypt=True):
    word = input("Enter the text: ")
    k = int(input("Enter the key offset: "))
    k = k if encrypt else -k  # Adjust key for encryption or decryption
    result = []
    
    for i in word:
        if i.isalpha():
            offset = 65 if i.isupper() else 97  # 65 for 'A', 97 for 'a'
            shifted = (ord(i) - offset + k) % 26 + offset
            result.append(chr(shifted))
        else:
            result.append(i)  # Preserve spaces and non-alphabetic characters

    return ''.join(result)

print(caesar_cipher())  # Encryption
print(caesar_cipher(False))  # Decryption

"""
#monoalphabetic-same code as cesar cipher but the key offset can be any
#polyalphabetic

def polyalphabetic_cipher():
    word = input("Enter the plain text: ")
    key = input("Enter the numeric key: ")
    
    # Convert key into a list of integer shifts
    s = [int(k) for k in key]
    c = ''
    for i, letter in enumerate(word):
        if letter == ' ':c += ' '
        else:
            shift = s[i % len(s)]  # Cycle through the numeric key
            c += chr((ord(letter) - ord('a') + shift) % 26 + ord('a'))  # Shift within a-z range
    return c

print(polyalphabetic_cipher())


