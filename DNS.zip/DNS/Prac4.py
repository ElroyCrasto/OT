import math
p = int(input("Enter a prime first number: "))
q = int(input("Enter a prime second number: "))
if p != q:
    plaintext = int(input("Enter plaintext number: "))
    n, phi = p * q, (p - 1) * (q - 1)
    
    if math.gcd(p, phi) == 1:
        e, d = 1, pow(1, -1, phi)
        print(f"Public key: ({e}, {n})")
        print(f"Private key: ({d}, {n})")
        
        if plaintext < n:
            C = pow(plaintext, e, n)
            P = pow(C, d, n)
            print(f"Ciphertext: {C}")
            print(f"Decrypted plaintext: {P}")
        else:
            print("Plaintext cannot be greater than n")
else:
    print("Prime numbers cannot be the same")
