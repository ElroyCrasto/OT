"""
#SHA-256
import hashlib
input="what a great day"
result=hashlib.sha256(input.encode())
print("the hexadecimal for Sha256 is:")
print(result.hexdigest())

#SHA512
import hashlib
input="Name 1234$"
result=hashlib.sha512(input.encode())
print("the hex equivalent for sha512 is:")
print(result.hexdigest())

#Sha384
import hashlib
input="$abcdef"

result=hashlib.sha384(input.encode())
print("the hex equivalent for sha384 is:")
print(result.hexdigest())

#sha224
import hashlib
input="$abcdef"

result=hashlib.sha224(input.encode())
print("the hex equivalent for sha224 is:")
print(result.hexdigest())
"""
#SHA1
import hashlib
input="this is great"

result=hashlib.sha1(input.encode())
print("the hex equivalent for sha1 is:")
print(result.hexdigest())
