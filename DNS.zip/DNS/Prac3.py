
#Aes
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from Crypto.Random import get_random_bytes

def main():
    key = b'mysecretpass1231'  # 16 bytes key for AES-128
    iv = get_random_bytes(AES.block_size)  # Initialization vector (IV)
    cipher = AES.new(key, AES.MODE_CBC, iv)
    
    plaintext = b'hello, world!'
    cipher_text = cipher.encrypt(pad(plaintext, AES.block_size))
    print("Encrypted:", cipher_text)

    decrypt_cipher = AES.new(key, AES.MODE_CBC, iv)
    decrypted_text = unpad(decrypt_cipher.decrypt(cipher_text), AES.block_size).decode()
    print("Decrypted:", decrypted_text)

if __name__ == '__main__':
    main()
"""
#Des
from Crypto.Cipher import DES
from Crypto.Random import get_random_bytes
def main():
    key = b'01234567'  # DES key must be exactly 8 bytes
    iv = get_random_bytes(DES.block_size)  # Initialization vector (IV)
    cipher = DES.new(key, DES.MODE_CFB, iv)
    
    text = 'KEYBOARD'
    cipher_text = cipher.encrypt(text.encode('utf-8'))
    print("Encrypted message:", cipher_text)

    # Create cipher object for decryption
    decrypt_cipher = DES.new(key, DES.MODE_CFB, iv)
    decrypted_text = decrypt_cipher.decrypt(cipher_text).decode('utf-8')
    print("Decrypted message:", decrypted_text)

if __name__ == '__main__':
    main()
"""