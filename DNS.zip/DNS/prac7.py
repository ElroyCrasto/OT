from hashlib import sha1
import hmac
text = b'plain text'
print('text:',text)
key = b'purav'
print('key:',key)

hashed=hmac.new(key,text,sha1)
print('hashed val:',hashed.digest())
"""
import hashlib
result = hashlib.md5(b'text')
print("the byte equivalent of hash is:",end="")
print(result.digest())
"""