def power(g, b, p):
    return pow(g, b, p)

def main():
    p = int(input("Enter a prime number (p): "))
    g = int(input("Enter any number (g): "))
    a, b = 4, 3  # Private keys for Alice and Bob
    print(f"Alice's private key (a): {a}")
    print(f"Bob's private key (b): {b}")
    x = power(g, a, p)
    y = power(g, b, p)
    
    ka = power(y, a, p)
    kb = power(x, b, p)
    print(f"Secret key for Alice: {ka}")
    print(f"Secret key for Bob: {kb}")
    
if __name__ == "__main__":
    main()
